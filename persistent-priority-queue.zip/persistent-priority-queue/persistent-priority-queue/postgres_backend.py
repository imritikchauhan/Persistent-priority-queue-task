"""
postgres_backend.py
====================
OPTIONAL / bonus alternative to module.py's file-based storage.

The assignment allows persistence via "file-based storage OR a relational
database (PostgreSQL only)". module.py implements the file-based version,
which has no external dependencies and is what test_module.py exercises.

This file provides an equivalent PostgresPriorityQueue with the exact same
public interface (insert, extract_min, extract_max, peek, update, delete,
is_empty), for anyone who wants to swap in PostgreSQL instead. It is not
required to run the test suite.

Design
------
Rather than reimplementing heap logic in SQL, we lean on the database as
the durable store of truth and let PostgreSQL's own indexing do the
ordering:

    CREATE TABLE pq_items (
        id         TEXT PRIMARY KEY,
        priority   DOUBLE PRECISION NOT NULL,
        value      JSONB,
        seq        BIGSERIAL
    );
    CREATE INDEX pq_items_priority_idx ON pq_items (priority, seq);

* insert       -> INSERT ... RETURNING id
* extract_min  -> SELECT ... ORDER BY priority ASC,  seq ASC LIMIT 1 FOR UPDATE
                  SKIP LOCKED, then DELETE it, inside one transaction
                  (safe under concurrent access).
* extract_max  -> same, ORDER BY priority DESC, seq ASC
* peek         -> same SELECT, without the DELETE
* update       -> UPDATE priority/value, seq bumped via a trigger/DEFAULT
* delete       -> DELETE ... WHERE id = %s
* is_empty     -> SELECT NOT EXISTS (SELECT 1 FROM pq_items)

The B-Tree index on (priority, seq) gives PostgreSQL an O(log n) path to
the min or max element directly, so no in-memory heap is needed at all;
the RDBMS's own index *is* the priority queue's ordering structure.

Requires: psycopg2-binary  (see requirements.txt)
"""

from __future__ import annotations

import json
from typing import Any, Dict, Optional

try:
    import psycopg2
    import psycopg2.extras
except ImportError:  # pragma: no cover
    psycopg2 = None

from module import EmptyPriorityQueueError, ItemNotFoundError


class PostgresPriorityQueue:
    def __init__(self, dsn: str, table: str = "pq_items"):
        """
        Parameters
        ----------
        dsn : str
            A libpq connection string / DSN, e.g.
            "dbname=pq_db user=pq_user password=... host=localhost"
        table : str
            Table name to use (created automatically if missing).
        """
        if psycopg2 is None:
            raise ImportError(
                "psycopg2 is required for PostgresPriorityQueue. "
                "Install it with: pip install psycopg2-binary"
            )
        self.table = table
        self._conn = psycopg2.connect(dsn)
        self._conn.autocommit = False
        self._init_schema()

    def _init_schema(self) -> None:
        with self._conn.cursor() as cur:
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {self.table} (
                    id         TEXT PRIMARY KEY,
                    priority   DOUBLE PRECISION NOT NULL,
                    value      JSONB,
                    seq        BIGSERIAL
                );
            """)
            cur.execute(f"""
                CREATE INDEX IF NOT EXISTS {self.table}_priority_idx
                ON {self.table} (priority, seq);
            """)
        self._conn.commit()

    def insert(self, priority: float, value: Any = None, id: Optional[str] = None) -> str:
        with self._conn.cursor() as cur:
            if id is None:
                cur.execute(
                    f"INSERT INTO {self.table} (id, priority, value) "
                    f"VALUES (gen_random_uuid()::text, %s, %s) RETURNING id",
                    (priority, json.dumps(value)),
                )
            else:
                cur.execute(
                    f"INSERT INTO {self.table} (id, priority, value) VALUES (%s, %s, %s) RETURNING id",
                    (str(id), priority, json.dumps(value)),
                )
            new_id = cur.fetchone()[0]
        self._conn.commit()
        return new_id

    def _extract(self, order: str) -> Dict[str, Any]:
        with self._conn.cursor() as cur:
            cur.execute(
                f"SELECT id, priority, value FROM {self.table} "
                f"ORDER BY priority {order}, seq ASC LIMIT 1 FOR UPDATE SKIP LOCKED"
            )
            row = cur.fetchone()
            if row is None:
                self._conn.rollback()
                raise EmptyPriorityQueueError("extract called on an empty queue")
            item_id, priority, value = row
            cur.execute(f"DELETE FROM {self.table} WHERE id = %s", (item_id,))
        self._conn.commit()
        return {"id": item_id, "priority": priority, "value": value}

    def extract_min(self) -> Dict[str, Any]:
        return self._extract("ASC")

    def extract_max(self) -> Dict[str, Any]:
        return self._extract("DESC")

    def peek(self, mode: str = "min") -> Dict[str, Any]:
        order = "ASC" if mode == "min" else "DESC"
        with self._conn.cursor() as cur:
            cur.execute(
                f"SELECT id, priority, value FROM {self.table} "
                f"ORDER BY priority {order}, seq ASC LIMIT 1"
            )
            row = cur.fetchone()
        if row is None:
            raise EmptyPriorityQueueError("peek() called on an empty queue")
        item_id, priority, value = row
        return {"id": item_id, "priority": priority, "value": value}

    def update(self, id: str, priority: Optional[float] = None, value: Any = None,
               update_value: bool = False) -> None:
        with self._conn.cursor() as cur:
            if priority is not None and update_value:
                cur.execute(
                    f"UPDATE {self.table} SET priority = %s, value = %s, "
                    f"seq = nextval(pg_get_serial_sequence('{self.table}', 'seq')) WHERE id = %s",
                    (priority, json.dumps(value), str(id)),
                )
            elif priority is not None:
                cur.execute(
                    f"UPDATE {self.table} SET priority = %s, "
                    f"seq = nextval(pg_get_serial_sequence('{self.table}', 'seq')) WHERE id = %s",
                    (priority, str(id)),
                )
            elif update_value:
                cur.execute(
                    f"UPDATE {self.table} SET value = %s WHERE id = %s",
                    (json.dumps(value), str(id)),
                )
            else:
                self._conn.rollback()
                return
            if cur.rowcount == 0:
                self._conn.rollback()
                raise ItemNotFoundError(f"no item with id {id!r}")
        self._conn.commit()

    def delete(self, id: str) -> None:
        with self._conn.cursor() as cur:
            cur.execute(f"DELETE FROM {self.table} WHERE id = %s", (str(id),))
            if cur.rowcount == 0:
                self._conn.rollback()
                raise ItemNotFoundError(f"no item with id {id!r}")
        self._conn.commit()

    def is_empty(self) -> bool:
        with self._conn.cursor() as cur:
            cur.execute(f"SELECT NOT EXISTS (SELECT 1 FROM {self.table})")
            return cur.fetchone()[0]

    def close(self) -> None:
        self._conn.close()
