"""
module.py
=========

A Persistent Priority Queue backed by file-based (JSON) storage.

Design summary
---------------
A priority queue that must support BOTH extract_min and extract_max
efficiently cannot be built on a plain binary heap (a binary heap is only
efficient for one direction). This implementation uses the classic
"two heaps + lazy deletion" technique:

    * A min-heap (`_min_heap`) gives O(log n) extract_min.
    * A max-heap (`_max_heap`) gives O(log n) extract_max.
    * A canonical dictionary (`_entries`) is the single source of truth
      for what is actually "in" the queue: {id -> {priority, value, seq}}.

Every heap entry is tagged with the id it belongs to and the "seq" number
that was current when it was pushed. When we pop from either heap we check
the popped entry against `_entries`:

    * If the id is missing from `_entries` -> the item was deleted -> discard.
    * If the seq stored in the heap entry does not match the seq in
      `_entries[id]` -> the item was updated after this heap entry was
      pushed (i.e. it is a stale duplicate) -> discard.
    * Otherwise it is valid.

`update()` and `delete()` never touch the heap arrays directly (removing an
arbitrary element from a binary heap is O(n)). Instead:

    * `update(id, ...)` bumps the seq counter, rewrites `_entries[id]`, and
      pushes a *new* entry into both heaps. The old heap entries become
      stale and are discarded lazily the next time they surface at the top.
    * `delete(id)` simply removes the id from `_entries`. Any heap entries
      referencing it become stale and are discarded lazily.

This keeps insert/update/delete/peek/extract all at O(log n) amortized
(occasionally O(k log n) while discarding a run of stale heap entries, but
each stale entry is discarded at most once, so it's amortized O(log n) per
original operation).

Persistence
-----------
The heaps themselves are NOT persisted (they are cheap to rebuild and doing
so keeps the on-disk format simple and human-readable). Instead we persist:

    * `_entries`  -> the canonical state of every item currently in the queue
    * `_counter`  -> the monotonically increasing sequence counter
    * `_next_id`  -> the next auto-generated integer id, if the caller
                     doesn't supply their own ids

On `load()`, the two heaps are rebuilt directly from `_entries`. Every
mutating operation calls `_persist()`, which writes to a temp file and
atomically renames it over the real file, so a crash mid-write can never
corrupt the on-disk state.

Supported operations
---------------------
    insert(priority, value=None, id=None) -> id
    extract_min() -> dict {id, priority, value}
    extract_max() -> dict {id, priority, value}
    peek(mode="min") -> dict {id, priority, value}   # mode in {"min","max"}
    update(id, priority=None, value=None) -> None
    delete(id) -> None
    is_empty() -> bool

Priorities may be any mutually-comparable value (int, float, etc). Ties are
broken FIFO, by insertion/update order, using the internal seq counter.
"""

from __future__ import annotations

import heapq
import json
import os
import tempfile
from typing import Any, Dict, Optional


class EmptyPriorityQueueError(Exception):
    """Raised when peek/extract is called on an empty queue."""


class ItemNotFoundError(KeyError):
    """Raised when update/delete is called with an id that isn't in the queue."""


class PriorityQueue:
    def __init__(self, storage_path: str = "pq_data.json", persist: bool = True):
        """
        Parameters
        ----------
        storage_path : str
            Path to the JSON file used for persistence.
        persist : bool
            If False, the queue behaves purely in-memory (useful for tests).
            Still attempts to load any pre-existing file at construction time.
        """
        self.storage_path = storage_path
        self._persist_enabled = persist

        self._entries: Dict[str, Dict[str, Any]] = {}
        self._counter: int = 0
        self._next_id: int = 1

        self._min_heap: list = []  # entries: [priority, seq, id]
        self._max_heap: list = []  # entries: [-priority, seq, id]  (negated for max-heap via heapq)

        self._load()

    # ------------------------------------------------------------------ #
    # Persistence
    # ------------------------------------------------------------------ #
    def _load(self) -> None:
        if os.path.exists(self.storage_path):
            with open(self.storage_path, "r") as f:
                data = json.load(f)
            self._entries = data.get("entries", {})
            self._counter = data.get("counter", 0)
            self._next_id = data.get("next_id", 1)
            self._rebuild_heaps()
        else:
            self._entries = {}
            self._counter = 0
            self._next_id = 1
            self._persist()

    def _rebuild_heaps(self) -> None:
        self._min_heap = []
        self._max_heap = []
        for item_id, entry in self._entries.items():
            priority = entry["priority"]
            seq = entry["seq"]
            self._min_heap.append([priority, seq, item_id])
            self._max_heap.append([-priority, seq, item_id])
        heapq.heapify(self._min_heap)
        heapq.heapify(self._max_heap)

    def _persist(self) -> None:
        if not self._persist_enabled:
            return
        data = {
            "entries": self._entries,
            "counter": self._counter,
            "next_id": self._next_id,
        }
        directory = os.path.dirname(os.path.abspath(self.storage_path))
        fd, tmp_path = tempfile.mkstemp(dir=directory, prefix=".pq_tmp_")
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_path, self.storage_path)  # atomic on POSIX
        except Exception:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _new_seq(self) -> int:
        self._counter += 1
        return self._counter

    def _is_valid(self, priority_key: float, seq: int, item_id: str, negated: bool) -> bool:
        entry = self._entries.get(item_id)
        if entry is None:
            return False
        if entry["seq"] != seq:
            return False
        stored_priority = -priority_key if negated else priority_key
        return stored_priority == entry["priority"]

    def _clean_top_min(self) -> None:
        while self._min_heap and not self._is_valid(
            self._min_heap[0][0], self._min_heap[0][1], self._min_heap[0][2], negated=False
        ):
            heapq.heappop(self._min_heap)

    def _clean_top_max(self) -> None:
        while self._max_heap and not self._is_valid(
            self._max_heap[0][0], self._max_heap[0][1], self._max_heap[0][2], negated=True
        ):
            heapq.heappop(self._max_heap)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def insert(self, priority: float, value: Any = None, id: Optional[str] = None) -> str:
        """Insert a new item. Returns the item's id (auto-generated if not given)."""
        if id is None:
            id = str(self._next_id)
            self._next_id += 1
        else:
            id = str(id)
            if id in self._entries:
                raise ValueError(f"id {id!r} already exists; use update() instead")

        seq = self._new_seq()
        self._entries[id] = {"priority": priority, "value": value, "seq": seq}
        heapq.heappush(self._min_heap, [priority, seq, id])
        heapq.heappush(self._max_heap, [-priority, seq, id])
        self._persist()
        return id

    def extract_min(self) -> Dict[str, Any]:
        """Remove and return the item with the lowest priority."""
        self._clean_top_min()
        if not self._min_heap:
            raise EmptyPriorityQueueError("extract_min() called on an empty queue")
        priority, seq, item_id = heapq.heappop(self._min_heap)
        entry = self._entries.pop(item_id)
        self._persist()
        return {"id": item_id, "priority": entry["priority"], "value": entry["value"]}

    def extract_max(self) -> Dict[str, Any]:
        """Remove and return the item with the highest priority."""
        self._clean_top_max()
        if not self._max_heap:
            raise EmptyPriorityQueueError("extract_max() called on an empty queue")
        neg_priority, seq, item_id = heapq.heappop(self._max_heap)
        entry = self._entries.pop(item_id)
        self._persist()
        return {"id": item_id, "priority": entry["priority"], "value": entry["value"]}

    def peek(self, mode: str = "min") -> Dict[str, Any]:
        """
        Return (without removing) the item with the lowest ('min') or
        highest ('max') priority.
        """
        if mode == "min":
            self._clean_top_min()
            if not self._min_heap:
                raise EmptyPriorityQueueError("peek() called on an empty queue")
            priority, seq, item_id = self._min_heap[0]
        elif mode == "max":
            self._clean_top_max()
            if not self._max_heap:
                raise EmptyPriorityQueueError("peek() called on an empty queue")
            neg_priority, seq, item_id = self._max_heap[0]
        else:
            raise ValueError("mode must be 'min' or 'max'")

        entry = self._entries[item_id]
        return {"id": item_id, "priority": entry["priority"], "value": entry["value"]}

    def update(self, id: str, priority: Optional[float] = None, value: Any = None,
               update_value: bool = False) -> None:
        """
        Update an existing item's priority and/or value.

        `priority`: new priority (leave as None to keep the current one).
        `value` / `update_value`: pass update_value=True to explicitly set
        value (even to None); otherwise the existing value is preserved
        unless a non-None `value` is given.
        """
        id = str(id)
        entry = self._entries.get(id)
        if entry is None:
            raise ItemNotFoundError(f"no item with id {id!r}")

        new_priority = entry["priority"] if priority is None else priority
        if update_value:
            new_value = value
        else:
            new_value = value if value is not None else entry["value"]

        seq = self._new_seq()
        self._entries[id] = {"priority": new_priority, "value": new_value, "seq": seq}
        heapq.heappush(self._min_heap, [new_priority, seq, id])
        heapq.heappush(self._max_heap, [-new_priority, seq, id])
        self._persist()

    def delete(self, id: str) -> None:
        """Remove an item from the queue by id."""
        id = str(id)
        if id not in self._entries:
            raise ItemNotFoundError(f"no item with id {id!r}")
        del self._entries[id]
        self._persist()
        # Stale heap entries referencing `id` are discarded lazily on next
        # peek/extract; we don't scan the heaps here to keep delete() O(1).

    def is_empty(self) -> bool:
        return len(self._entries) == 0

    def __len__(self) -> int:
        return len(self._entries)

    def __repr__(self) -> str:
        return f"PriorityQueue(size={len(self._entries)}, storage_path={self.storage_path!r})"
