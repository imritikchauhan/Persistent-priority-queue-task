"""
demo.py
========
A tiny runnable walkthrough of module.PriorityQueue.

Run with:
    python demo.py
"""

import os
from module import PriorityQueue

DB_FILE = "demo_pq_data.json"


def main():
    if os.path.exists(DB_FILE):
        os.remove(DB_FILE)

    print("--- Creating a persistent priority queue backed by", DB_FILE, "---")
    pq = PriorityQueue(storage_path=DB_FILE)

    print("\n--- Inserting support tickets (lower number = more urgent) ---")
    t1 = pq.insert(priority=3, value="Password reset request")
    t2 = pq.insert(priority=1, value="Production outage")
    t3 = pq.insert(priority=5, value="Feature request: dark mode")
    t4 = pq.insert(priority=2, value="Billing discrepancy")
    print(f"Inserted 4 tickets: {t1}, {t2}, {t3}, {t4}")
    print("Queue size:", len(pq))

    print("\n--- Peek at the most urgent (min) and least urgent (max) ---")
    print("Most urgent :", pq.peek("min"))
    print("Least urgent:", pq.peek("max"))

    print("\n--- Escalating the 'dark mode' ticket to urgent (priority 0) ---")
    pq.update(t3, priority=0)
    print("New most urgent:", pq.peek("min"))

    print("\n--- Customer withdrew the billing ticket; deleting it ---")
    pq.delete(t4)
    print("Queue size after delete:", len(pq))

    print("\n--- Simulating a process restart: reload from disk ---")
    del pq
    pq2 = PriorityQueue(storage_path=DB_FILE)
    print("Reloaded queue size:", len(pq2))

    print("\n--- Processing tickets in priority order (extract_min) ---")
    while not pq2.is_empty():
        print(" ->", pq2.extract_min())

    print("\nQueue empty:", pq2.is_empty())
    os.remove(DB_FILE)


if __name__ == "__main__":
    main()
