"""
test_module.py
===============
Unit tests for module.PriorityQueue.

Run with:
    python -m pytest test_module.py -v
or simply:
    python test_module.py
"""

import os
import unittest

from module import PriorityQueue, EmptyPriorityQueueError, ItemNotFoundError

TEST_FILE = "test_pq_data.json"


class TestPriorityQueue(unittest.TestCase):
    def setUp(self):
        if os.path.exists(TEST_FILE):
            os.remove(TEST_FILE)
        self.pq = PriorityQueue(storage_path=TEST_FILE)

    def tearDown(self):
        if os.path.exists(TEST_FILE):
            os.remove(TEST_FILE)

    def test_empty_queue(self):
        self.assertTrue(self.pq.is_empty())
        with self.assertRaises(EmptyPriorityQueueError):
            self.pq.extract_min()
        with self.assertRaises(EmptyPriorityQueueError):
            self.pq.extract_max()
        with self.assertRaises(EmptyPriorityQueueError):
            self.pq.peek()

    def test_insert_and_len(self):
        self.pq.insert(5, "five")
        self.pq.insert(1, "one")
        self.pq.insert(9, "nine")
        self.assertEqual(len(self.pq), 3)
        self.assertFalse(self.pq.is_empty())

    def test_peek_min_max(self):
        self.pq.insert(5, "five")
        self.pq.insert(1, "one")
        self.pq.insert(9, "nine")
        self.assertEqual(self.pq.peek("min")["value"], "one")
        self.assertEqual(self.pq.peek("max")["value"], "nine")
        # peek should not remove
        self.assertEqual(len(self.pq), 3)

    def test_extract_min_order(self):
        for p, v in [(5, "five"), (1, "one"), (9, "nine"), (3, "three")]:
            self.pq.insert(p, v)
        results = [self.pq.extract_min()["value"] for _ in range(4)]
        self.assertEqual(results, ["one", "three", "five", "nine"])
        self.assertTrue(self.pq.is_empty())

    def test_extract_max_order(self):
        for p, v in [(5, "five"), (1, "one"), (9, "nine"), (3, "three")]:
            self.pq.insert(p, v)
        results = [self.pq.extract_max()["value"] for _ in range(4)]
        self.assertEqual(results, ["nine", "five", "three", "one"])
        self.assertTrue(self.pq.is_empty())

    def test_interleaved_min_max_extraction(self):
        for p, v in [(5, "five"), (1, "one"), (9, "nine"), (3, "three"), (7, "seven")]:
            self.pq.insert(p, v)
        self.assertEqual(self.pq.extract_min()["value"], "one")
        self.assertEqual(self.pq.extract_max()["value"], "nine")
        self.assertEqual(self.pq.extract_min()["value"], "three")
        self.assertEqual(self.pq.extract_max()["value"], "seven")
        self.assertEqual(self.pq.extract_min()["value"], "five")
        self.assertTrue(self.pq.is_empty())

    def test_update_priority(self):
        id1 = self.pq.insert(5, "five")
        self.pq.insert(1, "one")
        self.pq.update(id1, priority=0)  # "five" now has the lowest priority
        self.assertEqual(self.pq.extract_min()["value"], "five")
        self.assertEqual(self.pq.extract_min()["value"], "one")

    def test_update_value(self):
        id1 = self.pq.insert(5, "old-value")
        self.pq.update(id1, value="new-value")
        self.assertEqual(self.pq.peek("min")["value"], "new-value")

    def test_update_missing_id_raises(self):
        with self.assertRaises(ItemNotFoundError):
            self.pq.update("nonexistent", priority=1)

    def test_delete(self):
        id1 = self.pq.insert(5, "five")
        id2 = self.pq.insert(1, "one")
        self.pq.delete(id2)
        self.assertEqual(len(self.pq), 1)
        self.assertEqual(self.pq.extract_min()["value"], "five")

    def test_delete_missing_id_raises(self):
        with self.assertRaises(ItemNotFoundError):
            self.pq.delete("nonexistent")

    def test_persistence_across_instances(self):
        self.pq.insert(3, "three")
        self.pq.insert(1, "one")
        self.pq.insert(2, "two")
        del self.pq  # simulate process exit

        pq2 = PriorityQueue(storage_path=TEST_FILE)
        self.assertEqual(len(pq2), 3)
        self.assertEqual(pq2.extract_min()["value"], "one")
        self.assertEqual(pq2.extract_min()["value"], "two")
        self.assertEqual(pq2.extract_min()["value"], "three")

    def test_persistence_survives_update_and_delete(self):
        id1 = self.pq.insert(10, "task-a")
        id2 = self.pq.insert(20, "task-b")
        self.pq.update(id1, priority=1)
        self.pq.delete(id2)
        del self.pq

        pq2 = PriorityQueue(storage_path=TEST_FILE)
        self.assertEqual(len(pq2), 1)
        item = pq2.extract_min()
        self.assertEqual(item["value"], "task-a")
        self.assertEqual(item["priority"], 1)

    def test_duplicate_priorities_fifo_tiebreak(self):
        self.pq.insert(1, "first")
        self.pq.insert(1, "second")
        self.pq.insert(1, "third")
        results = [self.pq.extract_min()["value"] for _ in range(3)]
        self.assertEqual(results, ["first", "second", "third"])

    def test_custom_id(self):
        self.pq.insert(5, "five", id="task-5")
        item = self.pq.peek("min")
        self.assertEqual(item["id"], "task-5")

    def test_duplicate_custom_id_raises(self):
        self.pq.insert(5, "five", id="task-5")
        with self.assertRaises(ValueError):
            self.pq.insert(1, "one", id="task-5")

    def test_stale_heap_entries_are_skipped(self):
        # Regression test for the lazy-deletion mechanism: after several
        # updates to the same id, only the freshest value should ever surface.
        id1 = self.pq.insert(100, "v1")
        self.pq.update(id1, priority=50, value="v2")
        self.pq.update(id1, priority=10, value="v3")
        self.pq.update(id1, priority=90, value="v4")
        self.assertEqual(len(self.pq), 1)
        item = self.pq.extract_min()
        self.assertEqual(item["value"], "v4")
        self.assertEqual(item["priority"], 90)
        self.assertTrue(self.pq.is_empty())


if __name__ == "__main__":
    unittest.main(verbosity=2)
