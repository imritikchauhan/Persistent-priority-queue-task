# Documentation: How This Project Was Solved, Step by Step

This document walks through the problem and the reasoning process end to
end — useful both as a record of *why* the code looks the way it does, and
as a guide if you want to re-derive or explain the solution in an
interview discussion.

---

## 1. Understand exactly what's being asked

The assignment requires a module exposing 7 operations:

| Operation     | What it does                                    |
|---------------|--------------------------------------------------|
| `insert`      | add a new (priority, value) item                 |
| `extract_min` | remove & return the lowest-priority item         |
| `extract_max` | remove & return the highest-priority item        |
| `peek`        | look at the top item without removing it         |
| `update`      | change an existing item's priority and/or value  |
| `delete`      | remove an item by id, without extracting it       |
| `is_empty`    | check whether the queue has anything in it        |

Two things immediately jump out as the interesting design constraints:

1. **Both `extract_min` and `extract_max` are required.** A textbook binary
   heap only gives you O(log n) access to *one* end (whichever the heap is
   ordered by). Getting the other end efficiently needs a different
   structure or a second heap.
2. **`update` and `delete` operate on an existing item by id**, not "the
   current top of the heap." Removing or re-prioritizing an *arbitrary*
   element from the middle of a binary heap is normally O(n) if done
   naively (you'd have to scan the array to find it).
3. **State must be persisted** — the queue has to survive the process
   restarting, so every mutation needs to be written to durable storage.

So the real problem isn't "implement a heap" (that part is easy) — it's
"support both-direction extraction *and* arbitrary update/delete *and*
persistence, all reasonably efficiently."

---

## 2. Decide on the priority-queue data structure

Two standard options solve the "min and max" problem:

**Option A — Min-max heap.** A single array where levels alternate
between "min levels" and "max levels" (level 0 is a min level, level 1 is
a max level, etc). Both extremes are reachable in O(1) (root = min,
root's children = candidates for max) and extraction is O(log n). It's
elegant but the trickle-down step is genuinely fiddly: at each step you
must compare a node against both its children *and* its grandchildren to
decide the sift direction, and it's easy to introduce a subtle bug that
only shows up on specific input orderings.

**Option B — Two heaps (min-heap + max-heap) with lazy deletion.** Keep
one ordinary min-heap and one ordinary max-heap, both referencing the same
canonical set of "live" items. This reuses Python's (or any language's)
already-correct, already-tested heap implementation for both directions,
and the only new logic needed is the bookkeeping that keeps the two heaps
in sync with what's "really" in the queue.

**Decision: Option B.** It trades a small amount of memory (each item's
key appears in two heap arrays instead of one) for a large reduction in
implementation risk, since the tricky part (heap invariant maintenance) is
delegated entirely to `heapq`, which is standard-library-tested. That
matches an SDE mindset of preferring boring, verifiable building blocks
over reimplementing a subtle algorithm from scratch under time pressure.

---

## 3. Solve "update/delete by id" — the lazy-deletion trick

Given two heaps, how do you efficiently change or remove an item that's
buried in the middle of a heap array, without an O(n) scan?

**Key insight:** you don't have to touch the heap array at all. You only
need the heap's *top* to be trustworthy when you look at it. So:

- Keep a separate dictionary, `_entries`, keyed by item id, holding the
  *current, correct* `{priority, value, seq}` for every item that is
  really in the queue right now. This dictionary is the single source of
  truth.
- Every time something is pushed into a heap, tag it with a `seq` number
  (a global counter, incremented on every insert/update).
- `update(id, new_priority)`: bump the seq counter, overwrite
  `_entries[id]` with the new priority/value/seq, and push a **new**
  `[priority, seq, id]` entry into both heaps. Don't touch the old entries
  still sitting in the heap arrays — just leave them there.
- `delete(id)`: simply remove `id` from `_entries`. Again, don't touch the
  heap arrays.
- Whenever you pop (or peek at) the top of a heap, check the popped/peeked
  entry against `_entries`: does the id still exist there, and does its
  `seq` match? If yes, it's valid — use it. If no (id was deleted, or a
  newer `seq` exists because of an `update`), it's a **stale duplicate** —
  discard it and look at the next one.

This means `insert`/`update`/`delete` are cheap (O(log n) or O(1) plus a
persist), and the "cleanup" cost of skipping stale entries is paid lazily,
spread out over future extract/peek calls — and each stale entry is only
ever discarded once, so the amortized cost per original operation stays
O(log n).

---

## 4. Solve persistence

Requirement: state must survive a process restart, using file storage or
PostgreSQL.

**Decision: JSON file** for the primary/required submission (simplicity,
human-readable, zero external dependencies — fits "any suitable name...
free to introduce additional files" and keeps setup instructions minimal).
A PostgreSQL-backed alternative is included separately as a bonus for
anyone who wants it, since the assignment explicitly allows either.

What actually needs to be written to disk? Notice the heap arrays
themselves are *redundant* — they can always be rebuilt from `_entries` by
calling `heapify()` on load. So only `_entries` (plus the seq counter and
an auto-id counter) needs to be persisted. This keeps the on-disk format
small, simple, and easy to inspect/debug by hand.

To avoid corrupting the file if the process dies mid-write, every write:

1. Writes the new JSON to a temp file in the same directory.
2. Calls `os.replace(tmp, real_path)`, which is atomic on POSIX — so the
   real file is either the old complete version or the new complete
   version, never a half-written mixture.

---

## 5. Design the public API

With the internal mechanics settled, the API surface follows directly
from the spec:

```python
pq = PriorityQueue(storage_path="pq_data.json")
id = pq.insert(priority, value=None, id=None)
pq.extract_min()          # -> {"id", "priority", "value"}
pq.extract_max()          # -> {"id", "priority", "value"}
pq.peek(mode="min")       # or mode="max"
pq.update(id, priority=None, value=None)
pq.delete(id)
pq.is_empty()
```

A couple of small decisions worth calling out:

- **Auto-generated ids** when the caller doesn't supply one, so `insert()`
  is usable standalone — but callers can also pass their own `id=` if they
  want to track their own external identifiers.
- **FIFO tie-breaking** for equal priorities, reusing the same `seq`
  counter that's already needed for staleness detection — no extra cost.
- **Explicit exceptions** (`EmptyPriorityQueueError`,
  `ItemNotFoundError`) rather than returning `None` on failure, so callers
  can't silently mishandle an empty-queue or missing-id case.

---

## 6. Verify correctness

Correctness for a structure like this hinges on a few specific risk areas,
so tests were written to target them directly rather than just "insert
some stuff and extract it":

- Basic ordering: `extract_min` / `extract_max` return items in the right
  order across a scattered set of priorities.
- **Interleaved min/max extraction** — extracting from both ends in
  alternation, to make sure the two heaps stay independently consistent
  with `_entries` as it shrinks.
- **Repeated updates to the same id** — the "stale heap entries" scenario
  described in step 3 — asserting that only the freshest value/priority is
  ever returned, never a stale one.
- **Persistence across instances** — write with one `PriorityQueue`
  object, discard it, construct a fresh one from the same file, and
  confirm state (including after updates/deletes) round-trips correctly.
- Error paths: empty-queue extraction/peek, updating/deleting a
  nonexistent id, inserting a duplicate explicit id.

All 17 tests pass (`python -m unittest test_module.py -v`).

`demo.py` additionally provides an end-to-end, human-readable walkthrough
(a support-ticket queue) that exercises insert, peek, update, delete, a
simulated restart, and full drain via `extract_min`.

---

## 7. Summary of the resulting design

- **Structure:** two `heapq`-based heaps (min + max) sharing one canonical
  `_entries` dict, kept consistent via lazy deletion on read.
- **Persistence:** `_entries` + counters serialized to JSON, written
  atomically on every mutation, heaps rebuilt from `_entries` on load.
- **Complexity:** O(log n) amortized for insert/extract/update; O(1) for
  delete/is_empty (with O(log n) cleanup deferred to later reads).
- **Why this shape:** it satisfies the two-directional-extraction and
  arbitrary-update/delete requirements without reimplementing a
  hand-rolled min-max heap, by leaning on a well-tested heap primitive
  twice instead of a novel structure once — a smaller, more verifiable
  surface area for the same guarantees.
